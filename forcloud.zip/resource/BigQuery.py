import json
from google.cloud import bigquery
from wrapper.wrapper import *
import logging

class InitBigQuery():
    def __init__(self):
        self.load_properties()
        self.client = bigquery.Client.from_service_account_json( self.SETTING['KEY_FILE'] )

        self.dataset_id     = bigquery.DatasetReference( self.SETTING['PROJECT'], self.SETTING['BIGQUERY_DATASET'] )
        self.stage_table_id = bigquery.TableReference( self.dataset_id, self.SETTING['STAGE_TABLE'] )
        self.get_or_create_resource()
      

    def load_properties(self):
        with open( 'properties/properties.json' ) as fin:
          self.SETTING = json.load( fin )
        with open( 'schemastore/salesorder.schema.json' ) as fin:
          self.SCHEMA = json.load( fin )
          
    def get_or_create_resource(self):
        self.dataset = bigquery.Dataset( self.dataset_id )
        self.dataset.location = 'US'
        self.dataset = get_or_create_dataset( self.dataset, self.client, self.dataset_id )

        self.stage_table = bigquery.Table( self.stage_table_id, schema = generate_schema( self.SCHEMA['STAGE'] ) )
        self.stage_table = get_or_create_table( self.stage_table, self.client, self.stage_table_id )        
        
