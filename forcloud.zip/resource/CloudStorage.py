import json, os
from google.cloud import storage
from wrapper.wrapper import *
import logging

class InitCloudStorage():
    def __init__(self):
      self.load_properties()
      self.client = storage.Client.from_service_account_json( self.SETTING['KEY_FILE'] )
      self.get_or_create_resource()

    def load_properties(self):
        with open( 'properties/properties.json' ) as fin:
          self.SETTING = json.load( fin )

    def get_or_create_resource(self):
        self.bucket = get_or_create_bucket( self.SETTING['BUCKET'], self.client )

    def upload_to_bucket(self):
        for (dirname, subdir, fname) in os.walk( self.SETTING['LOCAL_INPUT'] ):
          for f in fname:
            logging.info( 'Uploading {}'.format(f) )
            blob = self.bucket.blob( self.SETTING['BUCKET_FOLDER'] + f )
            blob.upload_from_filename( os.path.join(dirname, f) )
            logging.info( '{} uploaded'.format(f) )
            
    def move_to_archive(self):
        for blob in self.bucket.list_blobs( prefix=self.SETTING['BUCKET_FOLDER'] ):
            fname = blob.name.split('/')[-1]
            logging.info( 'Moving {} to archive'.format(fname) )
            self.bucket.copy_blob( blob, self.bucket, self.SETTING['BUCKET_ARCHIVE'] + fname )
            self.bucket.delete_blob( blob.name )
            logging.info( "{} moved to archive".format(fname) )


