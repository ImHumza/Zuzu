from google.cloud import storage
from google.cloud import bigquery
import logging

def get_or_create_dataset(ds, client, ds_id):
  try:
    ds = client.get_dataset( ds_id )
    logging.info( 'Dataset {} exist'.format(ds_id.dataset_id) )
  except:
    ds = client.create_dataset( ds )
    logging.info( 'Dataset {} created'.format(ds_id.dataset_id) )
  return ds

def get_or_create_table(table, client, table_id):
  try:
    table = client.get_table( table_id )
    logging.info( 'Table {} exist'.format(table_id.table_id) )
  except:
    table = client.create_table( table )
    logging.info( 'Table {} created'.format(table_id.table_id) )
  return table

def get_or_create_bucket(bucket, client ):
  try:
    bucket = client.get_bucket( bucket )
    logging.info( 'Bucket {} exist'.format(bucket.name) )
  except:
    bucket = client.create_bucket( bucket )
    logging.info( 'Bucket {} created'.format(bucket) )
  return bucket

  
def generate_schema(meta):
  schema = []
  for row in meta:
      schema.append( bigquery.SchemaField( row['name'], row['type'], mode = row['mode'] ) )

  return schema

