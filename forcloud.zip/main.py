import os
import logging

from resource.BigQuery import *
from resource.CloudStorage import *
from resource.PandasReadFromBigQuery import *

import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, GoogleCloudOptions, StandardOptions


class DFPipeline():
  def __init__(self):
      os.chdir( os.path.join( os.path.dirname( os.path.abspath( __file__ ) ), './' ) )
      self.load_properties()
      
      os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = self.SETTING['KEY_FILE']
      logging.info( 'Initializing BigQuery' )
      self.bq_obj = InitBigQuery()
      logging.info( 'Initializing Cloud Storage' )
      self.cs_obj = InitCloudStorage()
      
      self.cs_obj.upload_to_bucket()

  def load_properties(self):
      with open( 'properties/properties.json' ) as fin:
        self.SETTING = json.load( fin )
      with open( 'schemastore/salesorder.schema.json' ) as fin:
        self.SCHEMA = json.load( fin )

  
      
class PipelineRun:
  def __init__(self):
      self.load_properties()

      self.stage_table_id = "{}:{}.{}".format( self.SETTING['PROJECT'], self.SETTING['BIGQUERY_DATASET'], self.SETTING['STAGE_TABLE']  )
      self.stage_schema = ','.join( list( map( lambda field: field['name'] + ':' + field['type'], self.SCHEMA['STAGE'] ) ) )
      
      self.fields =  list( map( lambda field: field['name'], self.SCHEMA['STAGE'] ) )
      self.PIPELINE_OPTIONS = self.get_pipeline_options()

      
  def load_properties(self):
      with open( 'properties/properties.json' ) as fin:
        self.SETTING = json.load( fin )
      with open( 'schemastore/salesorder.schema.json' ) as fin:
        self.SCHEMA = json.load( fin )

  def parse_row(self, inp):
      import csv
      
      data = csv.reader( inp[1].split( '\n' ) )
      for csv_row in data:
          values = [ val for val in csv_row ]
          i = 0
          row = {}
          for value in values:
            row[ self.fields[i] ] = value
            i += 1
          return row

  def transformation(dataframe):
      import str
      ss = dataframe
      filter_values = ['S','X','R119']
      ss = ss[ss['SJCd'].str.contains('|'.join(filter_values))]
      ss['FinancialDayDt'] = ss['FinancialDayDt'].replace('-','')
      return ss
  
  
  def get_pipeline_options(self):
      options = PipelineOptions()
      
      gcp_options                    				= options.view_as( GoogleCloudOptions )
      gcp_options.job_name           				= self.SETTING['JOB_NAME']
      gcp_options.project            				= self.SETTING['PROJECT']
      gcp_options.staging_location   				= self.SETTING['STG_LOCATION']
      gcp_options.temp_location      				= self.SETTING['TEMP_LOCATION']
      gcp_options.service_account_email 			= self.SETTING['DF_SA']
      
      options.view_as( StandardOptions ).runner   	= self.SETTING['PIPELINE_RUNNER']
      
      return options

  
  def run(self):
      pipe = beam.Pipeline( options = self.PIPELINE_OPTIONS )
      source = pipe | beam.io.ReadFromTextWithFilename(
                                        file_pattern = self.SETTING['PIPELINE_SRC_PATTERN']
                                        , skip_header_lines = self.SETTING["FILE_HAS_HEADER"]
                                    )
      transformed = source | beam.Map( lambda r: self.parse_row(  r ) )
      #transformed1 = transformed | beam.ParDo(transformation())
      
      
      target = transformed | beam.io.WriteToBigQuery(
                                                self.stage_table_id
                                              , schema = self.stage_schema
                                              , method = beam.io.WriteToBigQuery.Method.FILE_LOADS
                                              , create_disposition = beam.io.BigQueryDisposition.CREATE_IF_NEEDED
                                              , write_disposition = beam.io.BigQueryDisposition.WRITE_TRUNCATE
                                    )
      logging.info( 'Running Pipeline' )
      import dill
      dill._dill._reverse_typemap['ClassType'] = type
      pipe.run().wait_until_finish()
      logging.info( 'Pipeline Completed' )

      
      
if __name__ == '__main__':  
  logging.getLogger().setLevel( logging.INFO )
  ingest = DFPipeline()
  
  pipe = PipelineRun()
  pipe.run()
  read_from_table()
  logging.info( 'BigqueryTransformationCompleted' )
